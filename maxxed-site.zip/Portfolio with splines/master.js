/*Master script for functionality*/
